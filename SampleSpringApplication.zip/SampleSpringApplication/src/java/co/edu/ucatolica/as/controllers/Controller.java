/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.ucatolica.as.controllers;

/**
 *
 * @author sala5
 */
public interface Controller {
    public abstract String processSubmit();
}
